# GaitFuseNet Experimental Results

These files contain the saved experimental outputs used for the GaitFuseNet project.

## 1. architecture_selection/
Single held-out split results for the architecture/baseline experiments.
These are kept separate from the later 5-fold cross-validation results.

- model1_imu_only.json
- model1_imu_only_regularized.json
- model2_insole_only.json
- model3_naive_late_fusion.json
- model4_cross_modal_attention.json
- model7_gated_fusion.json

## 2. cross_validation/
Fold-level results for feature/representation experiments and the final saved 5-fold run.

- model1_imu_only_5fold.csv
- model2_insole_raw_18feature_5fold.csv
- insole_21feature_5fold.csv
- insole_21feature_temporal_norm_5fold.csv
- insole_33feature_dynamic_5fold.csv
- gaitfusenet_final_5fold.csv

## 3. preprocessing/
Full multimodal GaitFuseNet 5-fold results under different insole signal-preprocessing conditions.

- gaitfusenet_no_filter_5fold.csv
- gaitfusenet_savitzky_golay_5fold.csv
- gaitfusenet_butterworth_5fold.csv
- gaitfusenet_median_filter_5fold.csv

## Important note

`gaitfusenet_final_5fold.csv` is preserved as a separate final saved run. Its fold-level values differ from the preprocessing-comparison files, so it should not be silently substituted for them in the report.

The `.pt` checkpoint files are intentionally not included here; they are model weights rather than result tables and should normally be excluded from the Git repository unless pretrained weights are explicitly being distributed.
